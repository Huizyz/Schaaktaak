//
// Created by toonc on 12/17/2021.
//

#ifndef SCHAKEN_FILEIO_H
#define SCHAKEN_FILEIO_H

#include <QFile>
bool openFileToWrite(QFile& file);
bool openFileToRead(QFile& file);

#endif //SCHAKEN_FILEIO_H
