//
// Created by toonc on 12/17/2021.
//

#ifndef SCHAKEN_MESSAGE_H
#define SCHAKEN_MESSAGE_H

#include <QString>

void message(const QString &s);

#endif //SCHAKEN_MESSAGE_H
